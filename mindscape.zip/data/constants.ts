export const POSTS_PER_PAGE = 9
