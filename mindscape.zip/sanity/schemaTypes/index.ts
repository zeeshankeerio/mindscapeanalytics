import { type SchemaTypeDefinition } from "sanity"

import { authorType } from "./authorType"
import { blockContentType } from "./blockContentType"
import { categoryType } from "./categoryType"
import { featuredType } from "./featuredTypes"
import { postType } from "./postType"
import { workplace_policy } from "./careers/workplace-policy"

export const schema: { types: SchemaTypeDefinition[] } = {
  types: [blockContentType, categoryType, postType, authorType, featuredType, workplace_policy],
}
